﻿namespace ConsoleApp3.Models
{
    internal interface IParkable
    {
        bool Park(List<Parking> parkings);
    }
}